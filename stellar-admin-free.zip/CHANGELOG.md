# CHANGELOG

## V 3.1.0
- package updation

## V 3.0.0
- Bootstrap5


## V 2.0.0
- Improved design
- New folder structure
- Updated plugins to newer version
- Other bug fixes

## V 1.0.0
- Initial release
