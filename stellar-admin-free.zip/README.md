## BootstrapDash Stellar Admin Template

### Documentation and Getting Started

The overall development documentation is available at `src/docs/documentation.html`.

Get the template up and running:

- npm install --global gulp-cli
- npm install
- cd src
- gulp serve

Yup, that's it.
